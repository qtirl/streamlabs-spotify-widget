async function updateUI() {
  try {
      const response = await fetch('/now-playing');
      const data = await response.json();
      if (data.songName && data.artistNames && data.albumArtUrl) {
          document.getElementById('song').textContent = data.songName;
          document.getElementById('artist').textContent = data.artistNames;
          document.getElementById('album-art').src = data.albumArtUrl;
      }
      if (data.progress !== undefined && data.duration !== undefined) {
          const percentage = (data.progress / data.duration) * 100;
          document.getElementById('progress-bar').style.width = percentage + '%';
      } else {
          console.error(data.error || 'Unexpected error');
      }
  } catch (err) {
      console.error('Error fetching playback state:', err);
  }
}

setInterval(updateUI, 1000);