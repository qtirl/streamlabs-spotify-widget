require('dotenv').config();

const express = require('express');
const SpotifyWebApi = require('spotify-web-api-node');
const path = require('path');

const app = express();
const port = 3000;

const spotifyApi = new SpotifyWebApi({
  clientId: process.env.SPOTIFY_CLIENT_ID,
  clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
  redirectUri: 'http://localhost:3000/callback',
});

app.use(express.static(path.join(__dirname, 'public')));

let lastLoggedTime = 0;
const logInterval = 6000; // 6 secs

function throttleLog(message) {
  const now = Date.now();
  if (now - lastLoggedTime >= logInterval) {
    console.log(message);
    lastLoggedTime = now;
  }
}

app.get('/login', (req, res) => {
  const scopes = ['user-read-playback-state'];
  res.redirect(spotifyApi.createAuthorizeURL(scopes));
});

app.get('/callback', async (req, res) => {
  const { code } = req.query;
  try {
    const data = await spotifyApi.authorizationCodeGrant(code);
    const { access_token: accessToken } = data.body;  
    if (accessToken) {
      spotifyApi.setAccessToken(accessToken);  
      res.send('Success! You can now close the window.');
      console.log('Success! You can now close the web browser.');
    } else {
      console.log('Error: Access token not found.');
      res.send('Error: Access token not found.');
    }
  } catch (err) {
    console.log('Error:', err.statusCode);
    res.send(`Error: ${err.statusCode}`);
  }
});

app.get('/now-playing', async (req, res) => {
  try {
    const data = await spotifyApi.getMyCurrentPlaybackState({});
    if (data.body && data.body.item) {
      const {
        item: {
          name: songName,
          artists,
          album: { images }
        },
        progress_ms: progress,
        item: { duration_ms: duration }
      } = data.body;

      const artistNames = artists.map(artist => artist.name).join(', ');

      const albumArtUrl = images[0]?.url || '';

      res.json({
        songName,
        artistNames,
        albumArtUrl,
        progress,
        duration
      });
    } else {
      throttleLog('Error: No track is playing');
      res.json({ error: 'No track is playing' });
    }
  } catch (err) {
    if (err.statusCode === 401) {

      throttleLog('Error 401: no token provided, please log in at http://localhost:3000/login');

      res.json({
        status: 'error 401',
        message: 'no token provided, please <a href="http://localhost:3000/login">log in</a>'
      });
    } else {
      throttleLog('Error fetching playback state'); 
      res.json({ error: 'Error fetching playback state' });
    }
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});